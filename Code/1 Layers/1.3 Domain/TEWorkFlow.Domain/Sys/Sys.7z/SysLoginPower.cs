﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NSH.Core.Domain;

namespace TEWorkFlow.Domain.Sys
{
    public class SysLoginPower : EntityGUIDBase, IAggregateRootGUID
    {
        public virtual string em_name { get; set; }
        public virtual string user_name { get; set; }
        public virtual string user_pw { get; set; }
        public virtual bool if_cash { get; set; }
        public virtual string cash_function { get; set; }
        public virtual string user_state { get; set; }
        public virtual decimal max_discount { get; set; }
        public virtual int user_type { get; set; }
        protected override void Validate()
        {
        }
    }
}
